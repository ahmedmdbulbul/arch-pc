%include 'in_out.asm'
SECTION .data
msg db "Результат: ",0
fx: db 'f(x)=6x+13 ',0

SECTION .text
global _start
_start:
mov eax, fx
call sprint
pop ecx 
pop edx
sub ecx,1
mov esi, 0

next:
cmp ecx,0h
jz _end 
pop eax
call atoi
call _calc
add esi,eax

loop next

_end:
mov eax, msg
call sprint
mov eax, esi
call iprintLF
call quit

_calc:
mov ebx,6 
mul ebx
add eax,13
ret
